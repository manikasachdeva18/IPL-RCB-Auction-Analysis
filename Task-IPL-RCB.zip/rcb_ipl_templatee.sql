/* =====================================================================
   RCB IPL STRATEGY — STUDENT ANSWER TEMPLATE
   ===================================================================== */

USE ipl;


/* =====================================================================
   OBJECTIVE QUESTIONS
   ===================================================================== */

-- O1
-- List the different dtypes of columns in table "ball_by_ball" (using
-- information schema)

SELECT
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'ipl'
  AND TABLE_NAME = 'Ball_by_Ball';

-- O2
-- What is the total number of runs scored in 1st season by RCB (bonus: also
-- include the extra runs using the extra runs table)
USE ipl;
SELECT
    SUM(COALESCE(bs.Runs_Scored, 0)) AS batsman_runs,
    SUM(COALESCE(er.Extra_Runs, 0)) AS extra_runs,
    SUM(COALESCE(bs.Runs_Scored, 0) +
        COALESCE(er.Extra_Runs, 0)) AS total_runs
FROM Ball_by_Ball b
JOIN Matches m
    ON b.Match_Id = m.Match_Id
LEFT JOIN Batsman_Scored bs
    ON b.Match_Id = bs.Match_Id
    AND b.Over_Id = bs.Over_Id
    AND b.Ball_Id = bs.Ball_Id
    AND b.Innings_No = bs.Innings_No
LEFT JOIN Extra_Runs er
    ON b.Match_Id = er.Match_Id
    AND b.Over_Id = er.Over_Id
    AND b.Ball_Id = er.Ball_Id
    AND b.Innings_No = er.Innings_No
WHERE b.Team_Batting = 2
  AND m.Season_Id = 1;


-- O3
-- How many players were more than the age of 25 during season 2014?
SELECT COUNT(DISTINCT p.Player_Id) AS players_over_25_in_2014 FROM Player p JOIN Player_Match pm ON p.Player_Id = pm.Player_Id JOIN Matches m ON pm.Match_Id = m.Match_Id WHERE m.Season_Id = 7 AND TIMESTAMPDIFF(YEAR, p.DOB, m.Match_Date) > 25;


-- O4
-- How many matches did RCB win in 2013?
SELECT COUNT(*) AS rcb_wins_2013 FROM Matches WHERE Season_Id = 6 AND Match_Winner = 2;


-- O5
-- List the top 10 players according to their strike rate in the last 4
-- seasons
SELECT p.Player_Name, SUM(bs.Runs_Scored) AS runs, SUM(CASE WHEN er.Extra_Type_Id = 2 THEN 0 ELSE 1 END) AS balls_faced, ROUND( SUM(bs.Runs_Scored) * 100.0 / SUM(CASE WHEN er.Extra_Type_Id = 2 THEN 0 ELSE 1 END), 2 ) AS strike_rate FROM Ball_by_Ball bbb JOIN Batsman_Scored bs USING (Match_Id, Over_Id, Ball_Id, Innings_No) JOIN Player p ON bbb.Striker = p.Player_Id JOIN Matches m USING (Match_Id) LEFT JOIN Extra_Runs er USING (Match_Id, Over_Id, Ball_Id, Innings_No) WHERE m.Season_Id IN (6, 7, 8, 9) GROUP BY p.Player_Id, p.Player_Name ORDER BY strike_rate DESC LIMIT 10;


-- O6
-- What are the average runs scored by each batsman considering all the
-- seasons?
SELECT p.Player_Name, SUM(bs.Runs_Scored) AS total_runs, COUNT(DISTINCT bbb.Match_Id) AS matches, ROUND( SUM(bs.Runs_Scored) * 1.0 / COUNT(DISTINCT bbb.Match_Id), 2 ) AS avg_runs_per_match FROM Ball_by_Ball bbb JOIN Batsman_Scored bs USING (Match_Id, Over_Id, Ball_Id, Innings_No) JOIN Player p ON bbb.Striker = p.Player_Id GROUP BY p.Player_Id, p.Player_Name ORDER BY p.Player_Name;


-- O7
-- What are the average wickets taken by each bowler considering all the
-- seasons?
WITH bowler_matches AS ( SELECT Bowler, COUNT(DISTINCT Match_Id) AS matches FROM Ball_by_Ball GROUP BY Bowler ), bowler_wickets AS ( SELECT bbb.Bowler, COUNT(*) AS total_wickets FROM Ball_by_Ball bbb JOIN Wicket_Taken wt USING (Match_Id, Over_Id, Ball_Id, Innings_No) WHERE wt.Kind_Out NOT IN (3, 5, 9) GROUP BY bbb.Bowler ) SELECT p.Player_Name, bw.total_wickets, bm.matches, ROUND(bw.total_wickets * 1.0 / bm.matches, 2) AS avg_wickets_per_match FROM bowler_wickets bw JOIN bowler_matches bm ON bw.Bowler = bm.Bowler JOIN Player p ON bw.Bowler = p.Player_Id ORDER BY p.Player_Name;


-- O8
-- List all the players who have average runs scored greater than the overall
-- average and who have taken wickets greater than the overall average
WITH bat AS ( SELECT b.Striker AS Player_Id, SUM(s.Runs_Scored) AS runs, COUNT(DISTINCT b.Match_Id) AS matches FROM Ball_by_Ball b JOIN Batsman_Scored s USING (Match_Id, Over_Id, Ball_Id, Innings_No) GROUP BY b.Striker ), bowl AS ( SELECT b.Bowler AS Player_Id, SUM(CASE WHEN w.Kind_Out NOT IN (3,5,9) THEN 1 ELSE 0 END) AS wickets, COUNT(DISTINCT b.Match_Id) AS matches FROM Ball_by_Ball b LEFT JOIN Wicket_Taken w USING (Match_Id, Over_Id, Ball_Id, Innings_No) GROUP BY b.Bowler ) SELECT p.Player_Name, ROUND(bat.runs / bat.matches, 2) AS avg_runs, ROUND(bowl.wickets / bowl.matches, 2) AS avg_wkts FROM bat JOIN bowl USING (Player_Id) JOIN Player p USING (Player_Id) WHERE bat.runs / bat.matches > (SELECT SUM(runs) / SUM(matches) FROM bat) AND bowl.wickets / bowl.matches > (SELECT SUM(wickets) / SUM(matches) FROM bowl);


-- O9
-- Create a table rcb_record table that shows the wins and losses of RCB in an
-- individual venue.
CREATE TABLE rcb_record AS SELECT v.Venue_Id, v.Venue_Name, SUM(CASE WHEN m.Match_Winner = 2 THEN 1 ELSE 0 END) AS wins, SUM(CASE WHEN m.Match_Winner <> 2 THEN 1 ELSE 0 END) AS losses FROM Matches m JOIN Venue v ON m.Venue_Id = v.Venue_Id WHERE m.Team_1 = 2 OR m.Team_2 = 2 GROUP BY v.Venue_Id, v.Venue_Name; SELECT * FROM rcb_record;


-- O10
-- What is the impact of bowling style on wickets taken?
SELECT bs.Bowling_skill AS bowling_style, COUNT(*) AS total_wickets, COUNT(DISTINCT b.Bowler) AS num_bowlers, ROUND(COUNT(*) / COUNT(DISTINCT b.Bowler), 2) AS wickets_per_bowler FROM Ball_by_Ball b JOIN Wicket_Taken w USING (Match_Id, Over_Id, Ball_Id, Innings_No) JOIN Player p ON b.Bowler = p.Player_Id JOIN Bowling_Style bs ON p.Bowling_skill = bs.Bowling_Id WHERE w.Kind_Out NOT IN (3, 5, 9) GROUP BY bs.Bowling_Id, bs.Bowling_skill ORDER BY total_wickets DESC;


-- O11
-- Write the SQL query to provide a status of whether the performance of the
-- team is better than the previous year's performance on the basis of the
-- number of runs scored by the team in the season and the number of
-- wickets taken

WITH stats AS 
( SELECT s.Season_Year, 
SUM(CASE WHEN b.Team_Batting = 2 THEN bs.Runs_Scored ELSE 0 END) AS runs, 
COUNT(CASE WHEN b.Team_Bowling = 2 AND w.Kind_Out NOT IN (3,5,9) THEN 1 END) AS wkts 
FROM Season s JOIN Matches m ON s.Season_Id = m.Season_Id 
JOIN Ball_by_Ball b ON m.Match_Id = b.Match_Id 
JOIN Batsman_Scored bs ON b.Match_Id = bs.Match_Id 
AND b.Over_Id = bs.Over_Id AND b.Ball_Id = bs.Ball_Id 
AND b.Innings_No = bs.Innings_No 
LEFT JOIN Wicket_Taken w ON b.Match_Id = w.Match_Id 
AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id 
AND b.Innings_No = w.Innings_No 
WHERE s.Season_Year BETWEEN 2012 AND 2016 
GROUP BY s.Season_Year ), x AS ( SELECT *, LAG(runs) OVER(ORDER BY Season_Year) AS prev_runs, 
LAG(wkts) OVER(ORDER BY Season_Year) AS prev_wkts FROM stats ) 
SELECT Season_Year, runs, wkts, runs - prev_runs AS runs_vs_prev, 
wkts - prev_wkts AS wkts_vs_prev, 
CASE WHEN runs > prev_runs AND wkts > prev_wkts 
THEN 'Better' ELSE 'Not Better' END AS performance_status FROM x 
WHERE Season_Year >= 2013;

-- O12
-- Can you derive more KPIs for the team strategy?
-- 1. RCB win % by season
SELECT s.Season_Year, COUNT(*) AS played, 
SUM(m.Match_Winner = 2) AS wins, 
ROUND(SUM(m.Match_Winner = 2) * 100.0 / COUNT(*), 2) AS win_pct 
FROM Matches m JOIN Season s ON m.Season_Id = s.Season_Id 
WHERE (m.Team_1 = 2 OR m.Team_2 = 2) 
AND s.Season_Year BETWEEN 2013 AND 2016 
GROUP BY s.Season_Year;
-- 2. Boundary reliance % of RCB runs from 4s and 6s
SELECT ROUND( SUM(CASE WHEN bs.Runs_Scored IN (4,6) 
THEN bs.Runs_Scored ELSE 0 END) * 100.0 / SUM(bs.Runs_Scored), 2 ) 
AS pct_runs_from_boundaries 
FROM Ball_by_Ball b JOIN Batsman_Scored bs 
ON b.Match_Id = bs.Match_Id 
AND b.Over_Id = bs.Over_Id 
AND b.Ball_Id = bs.Ball_Id 
AND b.Innings_No = bs.Innings_No 
WHERE b.Team_Batting = 2;
-- 3. Top 5 RCB run-scorers
SELECT p.Player_Name, SUM(bs.Runs_Scored) AS runs 
FROM Ball_by_Ball b JOIN Batsman_Scored bs 
ON b.Match_Id = bs.Match_Id 
AND b.Over_Id = bs.Over_Id 
AND b.Ball_Id = bs.Ball_Id 
AND b.Innings_No = bs.Innings_No 
JOIN Player p ON b.Striker = p.Player_Id 
WHERE b.Team_Batting = 2 
GROUP BY p.Player_Id, p.Player_Name 
ORDER BY runs DESC 
LIMIT 5;



-- O13
-- Using SQL, write a query to find out the average wickets taken by each
-- bowler in each venue. Also, rank the gender according to the average
-- value.
WITH stats AS ( SELECT m.Venue_Id, b.Bowler, 
COUNT(DISTINCT b.Match_Id) AS matches, 
SUM(CASE WHEN w.Kind_Out NOT IN (3,5,9) THEN 1 ELSE 0 END) AS wickets 
FROM Ball_by_Ball b JOIN Matches m ON b.Match_Id = m.Match_Id 
LEFT JOIN Wicket_Taken w ON b.Match_Id = w.Match_Id 
AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id 
AND b.Innings_No = w.Innings_No 
GROUP BY m.Venue_Id, b.Bowler ) 
SELECT v.Venue_Name, p.Player_Name, s.wickets, 
ROUND(s.wickets * 1.0 / s.matches, 2) AS avg_wickets, 
DENSE_RANK() OVER ( PARTITION BY s.Venue_Id ORDER BY s.wickets * 1.0 / s.matches DESC ) 
AS venue_rank FROM stats s JOIN Venue v 
ON s.Venue_Id = v.Venue_Id JOIN Player p 
ON s.Bowler = p.Player_Id 
WHERE s.wickets > 0 ORDER BY v.Venue_Name, venue_rank;


-- O14
-- Which of the given players have consistently performed well in past
-- seasons? (will you use any visualization to solve the problem)
use ipl;
WITH yearly AS ( SELECT p.Player_Id, p.Player_Name, s.Season_Year, 
SUM(bs.Runs_Scored) AS runs 
FROM Ball_by_Ball b JOIN Batsman_Scored bs 
ON b.Match_Id = bs.Match_Id AND b.Over_Id = bs.Over_Id 
AND b.Ball_Id = bs.Ball_Id AND b.Innings_No = bs.Innings_No 
JOIN Matches m ON b.Match_Id = m.Match_Id 
JOIN Season s ON m.Season_Id = s.Season_Id 
JOIN Player p ON b.Striker = p.Player_Id 
WHERE s.Season_Year BETWEEN 2013 AND 2016 
GROUP BY p.Player_Id, p.Player_Name, s.Season_Year ) 
SELECT Player_Name, COUNT(*) AS seasons_played, 
ROUND(AVG(runs), 2) AS avg_runs_per_season, 
SUBSTRING_INDEX(GROUP_CONCAT(Season_Year ORDER BY runs), ',', 1) 
AS worst_season, SUBSTRING_INDEX(GROUP_CONCAT(Season_Year ORDER BY runs DESC), ',', 1) 
AS best_season, ROUND(STDDEV_POP(runs), 2) AS runs_stddev 
FROM yearly GROUP BY Player_Id, Player_Name 
HAVING COUNT(*) = 4 ORDER BY avg_runs_per_season DESC;


-- O15
-- Are there players whose performance is more suited to specific venues or
-- conditions? (how would you present this using charts?)
SELECT p.Player_Name, v.Venue_Name, 
SUM(s.Runs_Scored) AS runs, 
SUM(CASE WHEN er.Extra_Type_Id = 2 THEN 0 ELSE 1 END) AS balls,
ROUND( SUM(s.Runs_Scored) * 100.0 / 
SUM(CASE WHEN er.Extra_Type_Id = 2 THEN 0 ELSE 1 END), 2 ) 
AS strike_rate FROM Ball_by_Ball b 
JOIN Batsman_Scored s ON b.Match_Id = s.Match_Id 
AND b.Over_Id = s.Over_Id AND b.Ball_Id = s.Ball_Id 
AND b.Innings_No = s.Innings_No JOIN Matches m 
ON b.Match_Id = m.Match_Id JOIN Venue v ON m.Venue_Id = v.Venue_Id 
JOIN Player p ON b.Striker = p.Player_Id 
LEFT JOIN Extra_Runs er ON b.Match_Id = er.Match_Id 
AND b.Over_Id = er.Over_Id AND b.Ball_Id = er.Ball_Id 
AND b.Innings_No = er.Innings_No 
GROUP BY p.Player_Id, p.Player_Name, v.Venue_Id, v.Venue_Name 
HAVING balls >= 60 ORDER BY strike_rate DESC LIMIT 25;



/* =====================================================================
   SUBJECTIVE QUESTIONS
   ===================================================================== */

-- S1
-- How does the toss decision affect the result of the match? (which
-- visualizations could be used to present your answer better) And is the
-- impact limited to only specific venues?
-- Overall toss impact

SELECT td.Toss_Name AS toss_decision, 
COUNT(*) AS matches, 
SUM(m.Toss_Winner = m.Match_Winner) 
AS toss_winner_wins, 
ROUND( SUM(m.Toss_Winner = m.Match_Winner) 
* 100.0 / COUNT(*), 2 ) AS win_pct 
FROM Matches m JOIN Toss_Decision td 
ON m.Toss_Decide = td.Toss_Id 
GROUP BY td.Toss_Name;

-- Venue-wise impact 
SELECT v.Venue_Name, td.Toss_Name AS toss_decision, 
COUNT(*) AS matches, ROUND( SUM(m.Toss_Winner = m.Match_Winner) 
* 100.0 / COUNT(*), 2 ) AS win_pct 
FROM Matches m JOIN Toss_Decision td 
ON m.Toss_Decide = td.Toss_Id 
JOIN Venue v ON m.Venue_Id = v.Venue_Id 
GROUP BY v.Venue_Name, td.Toss_Name 
ORDER BY v.Venue_Name, win_pct DESC;



-- S2
-- Suggest some of the players who would be best fit for the team.
 
WITH bat AS ( SELECT b.Striker AS Player_Id, SUM(s.Runs_Scored) AS runs 
FROM Ball_by_Ball b JOIN Batsman_Scored s ON b.Match_Id=s.Match_Id 
AND b.Over_Id=s.Over_Id AND b.Ball_Id=s.Ball_Id AND b.Innings_No=s.Innings_No 
GROUP BY b.Striker ), 
bowl AS ( SELECT b.Bowler AS Player_Id, COUNT(*) AS wickets 
FROM Ball_by_Ball b JOIN Wicket_Taken w ON b.Match_Id=w.Match_Id 
AND b.Over_Id=w.Over_Id AND b.Ball_Id=w.Ball_Id AND b.Innings_No=w.Innings_No 
WHERE w.Kind_Out NOT IN (3,5,9) GROUP BY b.Bowler ), 
stats AS ( SELECT p.Player_Id, p.Player_Name, COALESCE(bat.runs,0) AS runs, 
COALESCE(bowl.wickets,0) AS wickets 
FROM Player p LEFT JOIN bat ON p.Player_Id = bat.Player_Id LEFT JOIN bowl 
ON p.Player_Id = bowl.Player_Id ), 
ranked AS ( SELECT *, CASE WHEN runs >= 500 AND wickets >= 20 THEN 'All-Rounder' 
WHEN runs >= 500 THEN 'Batsman' WHEN wickets >= 20 THEN 'Bowler' 
END AS best_fit, 
ROW_NUMBER() OVER ( PARTITION BY CASE WHEN runs >= 500 AND wickets >= 20 THEN 'All-Rounder' 
WHEN runs >= 500 THEN 'Batsman' WHEN wickets >= 20 THEN 'Bowler' END 
ORDER BY runs DESC, wickets DESC ) AS rn FROM stats ) 
SELECT Player_Name, runs, wickets, best_fit FROM ranked 
WHERE best_fit IS NOT NULL AND rn <= 10 ORDER BY best_fit, rn;

-- S3
-- What are some of the parameters that should be focused on while selecting
-- the players?

WITH bat AS ( SELECT b.Striker AS Player_Id, SUM(bs.Runs_Scored) AS runs, 
SUM(CASE WHEN er.Extra_Type_Id = 2 THEN 0 ELSE 1 END) AS balls 
FROM Ball_by_Ball b JOIN Batsman_Scored bs ON b.Match_Id = bs.Match_Id 
AND b.Over_Id = bs.Over_Id AND b.Ball_Id = bs.Ball_Id AND b.Innings_No = bs.Innings_No 
LEFT JOIN Extra_Runs er ON b.Match_Id = er.Match_Id AND b.Over_Id = er.Over_Id 
AND b.Ball_Id = er.Ball_Id AND b.Innings_No = er.Innings_No 
GROUP BY b.Striker ), 
bowl AS ( SELECT b.Bowler AS Player_Id, COUNT(*) AS wickets 
FROM Ball_by_Ball b JOIN Wicket_Taken w ON b.Match_Id = w.Match_Id 
AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id AND b.Innings_No = w.Innings_No 
WHERE w.Kind_Out NOT IN (3,5,9) GROUP BY b.Bowler ), 
experience AS ( SELECT pm.Player_Id, COUNT(DISTINCT pm.Match_Id) AS matches, COUNT(DISTINCT m.Season_Id) AS seasons 
FROM Player_Match pm JOIN Matches m ON pm.Match_Id = m.Match_Id GROUP BY pm.Player_Id ) 
SELECT p.Player_Name, COALESCE(bat.runs,0) AS total_runs, 
ROUND(COALESCE(bat.runs * 100.0 / NULLIF(bat.balls,0),0),2) AS strike_rate, 
COALESCE(bowl.wickets,0) AS total_wickets, e.matches AS matches_played, 
e.seasons AS seasons_played FROM Player p JOIN experience e ON p.Player_Id = e.Player_Id 
LEFT JOIN bat ON p.Player_Id = bat.Player_Id 
LEFT JOIN bowl ON p.Player_Id = bowl.Player_Id 
ORDER BY total_runs DESC, total_wickets DESC;


-- S4
-- Which players offer versatility in their skills and can contribute
-- effectively with both bat and ball? (can you visualize the data for the
-- same)

WITH bat AS ( SELECT b.Striker AS Player_Id, SUM(s.Runs_Scored) AS runs 
FROM Ball_by_Ball b JOIN Batsman_Scored s ON b.Match_Id=s.Match_Id 
AND b.Over_Id=s.Over_Id AND b.Ball_Id=s.Ball_Id AND b.Innings_No=s.Innings_No 
GROUP BY b.Striker ), 
bowl AS ( SELECT b.Bowler AS Player_Id, COUNT(*) AS wickets 
FROM Ball_by_Ball b JOIN Wicket_Taken w ON b.Match_Id=w.Match_Id 
AND b.Over_Id=w.Over_Id AND b.Ball_Id=w.Ball_Id 
AND b.Innings_No=w.Innings_No 
WHERE w.Kind_Out NOT IN (3,5,9) 
GROUP BY b.Bowler ) 
SELECT p.Player_Name, bat.runs, bowl.wickets 
FROM bat JOIN bowl USING (Player_Id) JOIN Player p USING (Player_Id) 
WHERE bat.runs >= 500 AND bowl.wickets >= 20 
ORDER BY bat.runs DESC, bowl.wickets DESC LIMIT 10;


-- S5
-- Are there players whose presence positively influences the morale and
-- performance of the team? (justify your answer using visualization)

SELECT p.Player_Name, COUNT(pm.Match_Id) AS matches_played, 
SUM(m.Match_Winner = 2) AS wins, 
ROUND( SUM(m.Match_Winner = 2) * 100.0 / COUNT(pm.Match_Id), 2 ) AS win_pct 
FROM Player_Match pm JOIN Player p ON pm.Player_Id = p.Player_Id 
JOIN Matches m ON pm.Match_Id = m.Match_Id 
WHERE pm.Team_Id = 2 
GROUP BY p.Player_Id, p.Player_Name 
HAVING matches_played >= 10 
ORDER BY win_pct DESC LIMIT 10;

-- S6
-- What would you suggest to RCB before going to the mega auction?
WITH rcb AS ( SELECT s.Season_Year, COUNT(DISTINCT m.Match_Id) AS matches, 
SUM(CASE WHEN b.Team_Batting = 2 THEN bs.Runs_Scored ELSE 0 END) AS runs, 
SUM(CASE WHEN b.Team_Bowling = 2 AND w.Kind_Out NOT IN (3,5,9) THEN 1 ELSE 0 END) AS wickets, 
COUNT(DISTINCT CASE WHEN m.Match_Winner = 2 THEN m.Match_Id END) AS wins 
FROM Matches m JOIN Season s ON m.Season_Id = s.Season_Id 
JOIN Ball_by_Ball b ON m.Match_Id = b.Match_Id 
JOIN Batsman_Scored bs ON b.Match_Id = bs.Match_Id AND b.Over_Id = bs.Over_Id 
AND b.Ball_Id = bs.Ball_Id AND b.Innings_No = bs.Innings_No 
LEFT JOIN Wicket_Taken w ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id 
AND b.Innings_No = w.Innings_No WHERE s.Season_Year BETWEEN 2013 AND 2016 AND (m.Team_1 = 2 OR m.Team_2 = 2) 
GROUP BY s.Season_Year ), 
kpi AS ( SELECT *, ROUND(runs / matches, 2) AS runs_per_match, ROUND(wickets / matches, 2) AS wickets_per_match, 
ROUND(wins * 100.0 / matches, 2) AS win_pct FROM rcb ) 
SELECT Season_Year, runs_per_match, wickets_per_match, win_pct, 
CASE WHEN runs_per_match < AVG(runs_per_match) OVER() 
AND wickets_per_match < AVG(wickets_per_match) OVER() THEN 'Target All-Rounders' 
WHEN runs_per_match < AVG(runs_per_match) OVER() THEN 'Strengthen Batting' 
WHEN wickets_per_match < AVG(wickets_per_match) OVER() THEN 'Strengthen Bowling' ELSE 'Balanced' END AS auction_priority 
FROM kpi ORDER BY Season_Year;

-- S7
-- What do you think could be the factors contributing to the high-scoring
-- matches and the impact on viewership and team strategies

WITH match_stats AS
(SELECT m.Match_Id, s.Season_Year, v.Venue_Name,
SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS total_runs,
SUM(CASE WHEN bs.Runs_Scored = 4 THEN 1 ELSE 0 END) AS fours,
SUM(CASE WHEN bs.Runs_Scored = 6 THEN 1 ELSE 0 END) AS sixes,
SUM(COALESCE(er.Extra_Runs, 0)) AS extra_runs, COUNT(wt.Match_Id) AS wickets
FROM Matches m JOIN Season s ON m.Season_Id = s.Season_Id JOIN Venue v ON m.Venue_Id = v.Venue_Id
JOIN Ball_by_Ball b ON m.Match_Id = b.Match_Id
JOIN Batsman_Scored bs ON b.Match_Id = bs.Match_Id
AND b.Over_Id = bs.Over_Id AND b.Ball_Id = bs.Ball_Id
AND b.Innings_No = bs.Innings_No LEFT JOIN Extra_Runs er
ON b.Match_Id = er.Match_Id AND b.Over_Id = er.Over_Id
AND b.Ball_Id = er.Ball_Id AND b.Innings_No = er.Innings_No
LEFT JOIN Wicket_Taken wt ON b.Match_Id = wt.Match_Id
AND b.Over_Id = wt.Over_Id AND b.Ball_Id = wt.Ball_Id AND b.Innings_No = wt.Innings_No
GROUP BY m.Match_Id, s.Season_Year, v.Venue_Name),
average_score AS (SELECT AVG(total_runs) AS avg_match_runs FROM match_stats)
SELECT ms.Match_Id, ms.Season_Year, ms.Venue_Name, ms.total_runs, ms.fours, ms.sixes, ms.extra_runs, ms.wickets,
ROUND(((ms.fours * 4) + (ms.sixes * 6)) * 100.0/ NULLIF(ms.total_runs, 0),2) AS boundary_run_pct
FROM match_stats ms CROSS JOIN average_score a WHERE ms.total_runs > a.avg_match_runs
ORDER BY ms.total_runs DESC;

-- S8
-- Analyze the impact of home-ground advantage on team performance and
-- identify strategies to maximize this advantage for RCB.

WITH rcb_match_stats AS 
(SELECT m.Match_Id, CASE WHEN c.City_Name = 'Bangalore' THEN 'Home'
ELSE 'Away' END AS ground_type, m.Match_Winner, SUM(CASE WHEN b.Team_Batting = 2
THEN bs.Runs_Scored + COALESCE(er.Extra_Runs, 0) ELSE 0 END) AS rcb_runs,
SUM(CASE WHEN b.Team_Bowling = 2 AND w.Kind_Out NOT IN (3,5,9)
THEN 1 ELSE 0 END) AS rcb_wickets FROM Matches m
JOIN Venue v ON m.Venue_Id = v.Venue_Id JOIN City c
ON v.City_Id = c.City_Id JOIN Ball_by_Ball b
ON m.Match_Id = b.Match_Id JOIN Batsman_Scored bs ON b.Match_Id = bs.Match_Id
AND b.Over_Id = bs.Over_Id AND b.Ball_Id = bs.Ball_Id AND b.Innings_No = bs.Innings_No
LEFT JOIN Extra_Runs er ON b.Match_Id = er.Match_Id
AND b.Over_Id = er.Over_Id AND b.Ball_Id = er.Ball_Id AND b.Innings_No = er.Innings_No
LEFT JOIN Wicket_Taken w ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id
AND b.Ball_Id = w.Ball_Id AND b.Innings_No = w.Innings_No
WHERE m.Team_1 = 2 OR m.Team_2 = 2
GROUP BY m.Match_Id, ground_type, m.Match_Winner)
SELECT ground_type, COUNT(*) AS matches_played,
SUM(CASE WHEN Match_Winner = 2 THEN 1 ELSE 0 END) AS wins,
ROUND(SUM(CASE WHEN Match_Winner = 2 THEN 1 ELSE 0 END)* 100.0 / COUNT(*),2) AS win_percentage,
ROUND(AVG(rcb_runs), 2) AS avg_runs, ROUND(AVG(rcb_wickets), 2) AS avg_wickets
FROM rcb_match_stats GROUP BY ground_type ORDER BY ground_type DESC;

-- S9
-- Come up with a visual and analytical analysis of the RCB's past season's
-- performance and potential reasons for them not winning a trophy.

WITH ball_data AS 
(SELECT b.Match_Id, b.Over_Id, b.Ball_Id, b.Innings_No, b.Team_Batting, b.Team_Bowling, 
COALESCE(bs.Runs_Scored, 0) AS bat_runs, COALESCE(er.Extra_Runs, 0) AS extra_runs, w.Kind_Out
FROM Ball_by_Ball b LEFT JOIN Batsman_Scored bs ON b.Match_Id = bs.Match_Id
AND b.Over_Id = bs.Over_Id AND b.Ball_Id = bs.Ball_Id AND b.Innings_No = bs.Innings_No
LEFT JOIN Extra_Runs er ON b.Match_Id = er.Match_Id AND b.Over_Id = er.Over_Id
AND b.Ball_Id = er.Ball_Id AND b.Innings_No = er.Innings_No
LEFT JOIN Wicket_Taken w ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id AND b.Innings_No = w.Innings_No),
match_stats AS (SELECT m.Match_Id, s.Season_Year, m.Match_Winner,
SUM( CASE WHEN bd.Team_Batting = 2 THEN bd.bat_runs + bd.extra_runs ELSE 0 END) AS rcb_runs,
SUM(CASE WHEN bd.Team_Bowling = 2 THEN bd.bat_runs + bd.extra_runs ELSE 0 END) AS runs_conceded,
SUM(CASE WHEN bd.Team_Bowling = 2 AND bd.Kind_Out IS NOT NULL AND bd.Kind_Out NOT IN (3,5,9) THEN 1 ELSE 0 END
) AS wickets_taken FROM Matches m JOIN Season s ON m.Season_Id = s.Season_Id
JOIN ball_data bd ON m.Match_Id = bd.Match_Id WHERE m.Team_1 = 2 OR m.Team_2 = 2 GROUP BY m.Match_Id, s.Season_Year, m.Match_Winner)
SELECT Season_Year, COUNT(*) AS matches_played, SUM(CASE WHEN Match_Winner = 2 THEN 1 ELSE 0 END ) AS wins,
SUM(CASE WHEN Match_Winner IS NOT NULL AND Match_Winner <> 2 THEN 1 ELSE 0 END) AS losses,
SUM(CASE WHEN Match_Winner IS NULL THEN 1 ELSE 0 END) AS no_results,
ROUND(SUM(CASE WHEN Match_Winner = 2 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS win_percentage,
ROUND(AVG(rcb_runs), 2) AS avg_runs_scored, ROUND(AVG(runs_conceded), 2) AS avg_runs_conceded,
ROUND(AVG(wickets_taken), 2) AS avg_wickets_taken, ROUND(AVG(rcb_runs - runs_conceded),2) AS avg_run_difference
FROM match_stats GROUP BY Season_Year ORDER BY Season_Year;


-- S10
-- How would you approach this problem, if the objective and subjective
-- questions weren't given?
-- If the objective and subjective questions were not provided, I would first understand the available tables, columns, relationships, and data quality. Then I would perform exploratory analysis to identify important KPIs such as win percentage, runs scored, runs conceded, wickets taken, player performance, venue performance, toss impact, and season-wise trends.

-- After identifying patterns, I would focus on business questions such as:

-- Which seasons were RCB’s strongest and weakest?
-- Which players contributed most with bat and ball?
-- At which venues does RCB perform better?
-- Does toss decision affect match results?
-- What factors are associated with wins and losses?
-- Where does RCB need improvement in batting, bowling, or squad balance?

-- Finally, I would use SQL analysis and visualizations to summarize the findings and provide data-driven recommendations for team selection, auction strategy, venue strategy, and overall performance improvement.

-- 1. Understand available tables
SHOW TABLES;

-- 2. Understand important table structures
DESCRIBE Matches;
DESCRIBE Ball_by_Ball;
DESCRIBE Player;
DESCRIBE Player_Match;

-- 3. Check available seasons
SELECT
    Season_Id,
    Season_Year
FROM Season
ORDER BY Season_Year;

-- 4. RCB season-wise performance
SELECT
    s.Season_Year,
    COUNT(*) AS matches_played,
    SUM(m.Match_Winner = 2) AS wins,
    ROUND(
        SUM(m.Match_Winner = 2) * 100.0 / COUNT(*),
        2
    ) AS win_percentage
FROM Matches m
JOIN Season s
    ON m.Season_Id = s.Season_Id
WHERE m.Team_1 = 2
   OR m.Team_2 = 2
GROUP BY s.Season_Year
ORDER BY s.Season_Year;

-- 5. RCB venue-wise performance
SELECT
    v.Venue_Name,
    COUNT(*) AS matches_played,
    SUM(m.Match_Winner = 2) AS wins,
    ROUND(
        SUM(m.Match_Winner = 2) * 100.0 / COUNT(*),
        2
    ) AS win_percentage
FROM Matches m
JOIN Venue v
    ON m.Venue_Id = v.Venue_Id
WHERE m.Team_1 = 2
   OR m.Team_2 = 2
GROUP BY v.Venue_Id, v.Venue_Name
ORDER BY win_percentage DESC;

-- 6. Top RCB run scorers
SELECT
    p.Player_Name,
    SUM(bs.Runs_Scored) AS total_runs
FROM Ball_by_Ball b
JOIN Batsman_Scored bs
    ON b.Match_Id = bs.Match_Id
    AND b.Over_Id = bs.Over_Id
    AND b.Ball_Id = bs.Ball_Id
    AND b.Innings_No = bs.Innings_No
JOIN Player p
    ON b.Striker = p.Player_Id
WHERE b.Team_Batting = 2
GROUP BY p.Player_Id, p.Player_Name
ORDER BY total_runs DESC
LIMIT 10;


-- S11
-- In the "Match" table, some entries in the "Opponent_Team" column are
-- incorrectly spelled as "Delhi_Capitals" instead of "Delhi_Daredevils".
-- Write an SQL query to replace all occurrences of "Delhi_Capitals" with
-- "Delhi_Daredevils".

SELECT *
FROM Team
WHERE Team_Name LIKE '%Delhi%';

UPDATE Team
SET Team_Name = 'Delhi Daredevils'
WHERE Team_Id = 6
  AND Team_Name = 'Delhi Capitals';




/* ===================================== END OF FILE ===================================== */
